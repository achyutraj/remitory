<?php

namespace StripeJS;

/**
 * Class AlipayAccount
 *
 * @package StripeJS
 */
class AlipayAccount extends ExternalAccount
{

}

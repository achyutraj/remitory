<?php

namespace CoinGate\APIError;

# HTTP Status 401
class IpAddressIsNotAllowed extends Unauthorized
{
}


<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FirebaseNotify extends Model
{
	use HasFactory;

	protected $guarded = ['id'];
	protected $table = 'firebase_notifies';
}
